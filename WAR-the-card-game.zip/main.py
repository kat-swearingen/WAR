import pygame
import random

pygame.init()#inisilizes pygame
pygame.display.set_caption("War :)") # sets window titial
screen = pygame.display.set_mode((700,500))
clock = pygame.time.Clock()
#classes------------------------------------------------

class card:
  def __init__(self, suit, num): #constructor: MAKES the brick
    self.num = num
    self.suit = suit
 
  def draw(self, xpos, ypos):
    pygame.draw.rect(screen, (255, 255, 255), (xpos, ypos, 100, 180))
    pygame.draw.rect(screen, (0, 0, 0), (xpos, ypos, 100, 180),3)
    font = pygame.font.Font('freesansbold.ttf', 24)
    text = font.render(str(self.num), 1, (0,0,0))
    text2 = font.render(str(self.suit), 1, (250,0,0))
    screen.blit(text, (xpos+30,ypos+30))
    screen.blit(text2, (xpos+30,ypos+60))

    
  #collision function goes here
  #alive = False

c1 = card(0, 4)
c2 = card(2, 9)
c3 = card(1, 7)

#deck area thingy i dont know where to put this---------
deck = list()

#these next 3 lines make a standard deck of cards
for j in range (4):
  for i in range(13):
    deck.append(card(j, i))



random.shuffle(deck)

p1hand = list()
p2hand = list()
p1dis = list()
p2dis = list()

#these next 4 lines split the deck into two hands
for i in range(26): #puts in cards 1-25
  p1hand.append(deck[i])

for j in range(26, 52): #puts in cards 26-52
  p2hand.append(deck[j])


#len() is like randrange()






#game var-------------------------------------------------
doExit = False

while not doExit:#game loop start-------------------------
 
  # timee----------------------------------
  clock.tick(60)
  for event in pygame.event.get():
    if event.type==pygame.quit:
      doExit = True

  turn = False
 #player motion
  if event.type == pygame.MOUSEMOTION:
    mousepos =event.pos
  if event.type == pygame.MOUSEBUTTONDOWN:
    turn = True
  #try turning "turn" off when you have MOUSEBUTTONUP
  if event.type == pygame.MOUSEBUTTONUP:
   turn = False

 #game logic-------------------------------
  if len(p1hand)<=0 or len(p2hand)<=0:
    if len(p1dis)>len(p2dis):
      print("player 1 wins")
    else:
      print ("player 2 wins")
    doExit = True


  if turn and len (p1hand)> 0 and len (p2hand) > 0:
  
   if p1hand [len(p1hand)-1].num > p2hand [len(p2hand)-1].num:
     p1dis.append(p1hand [len(p1hand)-1])#put in p1 discard
     p1dis.append(p2hand [len(p2hand)-1])#put in p1 discard
     p1hand.pop(len(p1hand)-1)#remove from hand
     p2hand.pop(len(p2hand)-1)#remove from hand
   else:
     p2dis.append(p2hand [len(p2hand)-1])#put in p2 discard
     p2dis.append(p1hand [len(p1hand)-1])#put in p2 discard
     p2hand.pop(len(p2hand)-1)#remove from hand
     p1hand.pop(len(p1hand)-1)#remove from hand
    



 #render-----------------------------------
  screen.fill((0,150,0))# ALWAYS start render section with this
  #c1.draw(250,100)
  #c2.draw(100,200)
  #c3.draw(400,200)

  for i in range(0,len(p1hand)): 
    p1hand[i].draw(200, 50)

  for i in range(0,len(p2hand)): 
    p2hand[i].draw(200, 250)

  for i in range(0,len(p2dis)):
    p2dis[i].draw(400+6*i, 250)

  for i in range(0,len(p1dis)):
    p1dis[i].draw(400+6*i, 50)

#displays the whole deck
  #for i in range(52):
   # deck[i].draw(20+i*5, 20+i*3)

  pygame.display.flip() #alwasy end render section with this




pygame.quit()

